package com.liferay.training.gradebook.internal.security.permission.resource.definition;

import com.liferay.exportimport.kernel.staging.permission.StagingPermission;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.StagedModelPermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.definition.ModelResourcePermissionDefinition;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentLocalService;

import java.util.function.Consumer;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * The Class Represent For Registering Model and Top-Level Permission
 * @author rahulholalkere
 */
@Component(immediate = true, service = ModelResourcePermissionDefinition.class)
public class AssignmentModelResourcePermissionDefinition implements ModelResourcePermissionDefinition<Assignment>{
	/**
	 * Adding All The Related Metadata Method For The Registeration Process.
	 */
	@Override
	public Assignment getModel(long assignmentId) throws PortalException {
		return assignmentLocalService.getAssignment(assignmentId);
	}
	
	@Override
	public Class<Assignment> getModelClass() {
		return Assignment.class;
	}
	
	@Override
	public PortletResourcePermission getPortletResourcePermission() {
		return assignmentPortletResourcePermission;
	}
	
	@Override
	public long getPrimaryKey(Assignment assignment) {
		return assignment.getAssignmentId();
	}
	
	@Override
	public void registerModelResourcePermissionLogics(ModelResourcePermission<Assignment> modelResourcePermission, Consumer<ModelResourcePermissionLogic<Assignment>> modelResourcePermissionLogicConsumer) {
		modelResourcePermissionLogicConsumer.accept(
			new StagedModelPermissionLogic<>(stagingPermission, "com_liferay_training_gradebook_web_portlet_GradebookPortlet", Assignment::getAssignmentId)
		);
	}
	
	/**
	 * Adding All The Required Reference For This Permission Registeration
	 */
	@Reference
	private AssignmentLocalService assignmentLocalService;
	
	@Reference
	private GroupLocalService groupLocalService;
	
	@Reference(target = "(resource.name=com.liferay.training.gradebook.model)")
	private PortletResourcePermission assignmentPortletResourcePermission;
	
	@Reference
	private StagingPermission stagingPermission;
}
