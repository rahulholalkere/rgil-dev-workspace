/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.base.AssignmentLocalServiceBaseImpl;
import com.liferay.training.gradebook.validator.AssignmentValidator;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author hgrahul
 */
@Component(
	property = "model.class.name=com.liferay.training.gradebook.model.Assignment",
	service = AopService.class
)
public class AssignmentLocalServiceImpl extends AssignmentLocalServiceBaseImpl {
	public Assignment addAssignment(long groupId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Field Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Get Details About The Group and User Information
		Group currentGroup = groupLocalService.getGroup(groupId);
		
		long currentUserId = serviceContext.getUserId();
		User currentUser = userLocalService.getUser(currentUserId);
		
		// Generate A Primary Key For The New Assignment Creation
		long assignmentId = counterLocalService.increment(Assignment.class.getName());
		
		// Using The Generated Primary Key - Create A New Assignment
		Assignment newAssignment = createAssignment(assignmentId);
		
		// Populate Assignment Information To The Assignment Instance
		// 1. First Add Assignment Actual Information
		newAssignment.setTitleMap(titleMap);
		newAssignment.setDescriptionMap(descriptionMap);
		newAssignment.setDueDate(dueDate);
		
		// 2. Adding Other Related Information For Assignment Entity
		newAssignment.setGroupId(groupId);
		newAssignment.setCompanyId(currentGroup.getCompanyId());
		newAssignment.setCreateDate(new Date());
		newAssignment.setModifiedDate(new Date());
		newAssignment.setUserId(currentUserId);
		newAssignment.setUserName(currentUser.getScreenName());
		
		// Persist The Assignment
		newAssignment = super.addAssignment(newAssignment);
		
		// Adding Permissioned Resource or Making It A Proper Resource
		boolean portletActions = false;
		boolean addGuestPermissions = true;
		boolean addGroupPermissions = true;
		
		// Call For Resource Service To Make It A Resource
		resourceLocalService.addResources(currentGroup.getCompanyId(), groupId, currentUserId, Assignment.class.getName(), assignmentId, portletActions, addGroupPermissions, addGuestPermissions);
		
		// Finally Returning The Assignment Instances
		return newAssignment;
	}
	
	@Override
	public Assignment deleteAssignment(Assignment assignment) throws PortalException{
		// Delete The Permissioned Resource
		resourceLocalService.deleteResource(assignment, ResourceConstants.SCOPE_INDIVIDUAL);
		
		// Call For Deleting The Assignment Aswell
		return super.deleteAssignment(assignment);
	}
	
	public Assignment updateAssignment(long assignmentId, Map<Locale, String> titleMap, Map<Locale, String> descriptionMap, Date dueDate, ServiceContext serviceContext) throws PortalException {
		// Validate Assignment Field Values
		assignmentValidator.validate(titleMap, descriptionMap, dueDate);
		
		// Get The Assignment Information From The AssignmentId Recieved
		Assignment assignment = getAssignment(assignmentId);
		
		// Update Or Populate New Information To The Assignment Instances
		assignment.setTitleMap(titleMap);
		assignment.setDescriptionMap(descriptionMap);
		assignment.setDueDate(dueDate);
		
		// Update The Modified Date
		assignment.setModifiedDate(new Date());
		
		// Persist and Return Assignment
		return super.updateAssignment(assignment);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId) {
		return assignmentPersistence.findByGroupId(groupId);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId, int start, int end) {
		return assignmentPersistence.findByGroupId(groupId, start, end);
	}
	
	public List<Assignment> getAssignmentsByGroupId(long groupId, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		return assignmentPersistence.findByGroupId(groupId, start, end, orderByComparator);
	}
	
	private DynamicQuery getKeywordSearchDynamicQuery(long groupId, String keywords) {
		// Setting Up The Group / Website As Base Criteria
		DynamicQuery dynamicQuery = dynamicQuery().add(RestrictionsFactoryUtil.eq("groupId", groupId));
		
		// Checking If We Have A Keywords
		if(Validator.isNotNull(keywords)) {
			// Adding The Keywords To Be Search Against The Title And Desription
			Disjunction disjunctionQuery = RestrictionsFactoryUtil.disjunction();
			
			disjunctionQuery.add(RestrictionsFactoryUtil.like("title", "%" + keywords + "%"));
			disjunctionQuery.add(RestrictionsFactoryUtil.like("description", "%" + keywords + "%"));
			
			// Updating The Query
			dynamicQuery.add(disjunctionQuery);
		}

		// Return The Update Query After Updating Query
		return dynamicQuery;
	}
	
	public List<Assignment> getAssignmentsByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Assignment> orderByComparator) {
		return assignmentLocalService.dynamicQuery(getKeywordSearchDynamicQuery(groupId, keywords), start, end, orderByComparator);
	}
	
	public long getAssignmentsCountByKeywords(long groupId, String keywords) {
		return assignmentLocalService.dynamicQueryCount(getKeywordSearchDynamicQuery(groupId, keywords));
	}
	
	/**
	 * Silence Method So As To Avoid Overriding In Next Or Further Level
	 */
	@Override
	public Assignment addAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported At This Level");
	}
	
	@Override
	public Assignment updateAssignment(Assignment assignment) {
		throw new UnsupportedOperationException("Not Supported At This Level");
	}
	
	@Reference
	private AssignmentValidator assignmentValidator;
}