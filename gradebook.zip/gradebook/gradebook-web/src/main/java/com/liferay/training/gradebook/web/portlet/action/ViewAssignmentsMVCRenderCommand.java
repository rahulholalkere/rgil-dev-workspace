package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;
import com.liferay.training.gradebook.web.display.context.AssignmentsManagementToolbarDisplayContext;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;


/**
 * 
 * @author rahulholalkere
 * This Class Represents MVC Command For Showing A List Of Assignment Based On Appropriate Group Or Website.
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=/",
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENTS
	},
	service = MVCRenderCommand.class
)
public class ViewAssignmentsMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Adding Assignment List Related Attributes To Request
		addAssignmentListAttributes(renderRequest);
		
		// Adding Clay Management Toolbar For Showing Other Important Option
		addManagementToolbarAttributes(renderRequest, renderResponse);
		
		// Return To Appropriate View To Handle The Main View
		return "/view.jsp";
	}
	
	/**
	 * Adding Clay Management Toolbar Related Works
	 */
	public void addManagementToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		// To Pass The Current Liferay Portlet Request and Response + Http Servlet Request (Nothing But Page Request)
		LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
		LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
		HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);
		
		// Need To Instanciate A Assignment Clay Management Toolbar Class Which Does All Operations Relvant To Assignment
		AssignmentsManagementToolbarDisplayContext assignmentsManagementToolbarDisplayContext = new AssignmentsManagementToolbarDisplayContext(liferayPortletRequest, liferayPortletResponse, httpServletRequest);
		
		// We Need To Set The Assignment Clay Management Toolbar - Instance To The Request For View To Retrieve It.
		renderRequest.setAttribute("assignmentsManagementToolbarDisplayContext", assignmentsManagementToolbarDisplayContext);
	}
	
	/**
	 * Adds Assignment List Related Attributes To The Request
	 * @param renderRequest
	 */
	private void addAssignmentListAttributes(RenderRequest renderRequest) {
		// Get The Current Scope Or Website Id
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();

		// Resolve The Start and End Of The Search Container
		int currentPage = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_CUR);
		int delta = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_DELTA_PARAM, SearchContainer.DEFAULT_DELTA);
		
		int start = ((currentPage > 0) ? (currentPage - 1) : 0) * delta;
		int end = start + delta;
		
		// Getting The Sorting Options In Terms With Type And Column Information
		String orderByCol = ParamUtil.getString(renderRequest, "orderByCol", "title");
		String orderByType = ParamUtil.getString(renderRequest, "orderByType", "asc");
		
		// Creating OrderByComparator For Further Assignment Retrival Process
		OrderByComparator<Assignment> orderByComparator = OrderByComparatorFactoryUtil.create("Assignment", orderByCol, !("asc").equals(orderByType));
		
		// Getting The Keywords If Available
		String keywords = ParamUtil.getString(renderRequest, "keywords");
		
		// Now Call For The AssignmentService To Perform Actual Retrival Process.
		List<Assignment> assignments = assignmentService.getAssignmentsByKeywords(groupId, keywords, start, end, orderByComparator);
		long assignmentCount = assignments.size();
		
		// Set The Assignment List and Count Details To The Request Object
		renderRequest.setAttribute("assignmentCount", assignmentCount);
		renderRequest.setAttribute("assignments", assignments);
	}
	
	@Reference
	private Portal portal;
	
	@Reference
	private AssignmentService assignmentService;
}
