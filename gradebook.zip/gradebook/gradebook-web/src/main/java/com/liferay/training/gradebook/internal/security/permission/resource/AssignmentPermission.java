package com.liferay.training.gradebook.internal.security.permission.resource;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.training.gradebook.model.Assignment;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author rahulholalkere
 * This Class Represents Class For Checking Entity Permissions
 */
@Component(immediate = true, service = AssignmentPermission.class)
public class AssignmentPermission {
	public boolean contains(PermissionChecker permissionChecker, long assignmentId, String actionKeys) throws PortalException {
		return assignmentModelResourcePermission.contains(permissionChecker, assignmentId, actionKeys);
	}
	
	public boolean contains(PermissionChecker permissionChecker, Assignment assignment, String actionKeys) throws PortalException {
		return assignmentModelResourcePermission.contains(permissionChecker, assignment, actionKeys);
	}
	
	@Reference(target = "(model.class.name=com.liferay.training.gradebook.model.Assignment)", unbind = "-")
	protected void setAssignmentModelResourcePermission(ModelResourcePermission<Assignment> modelResourcePermission) {
		assignmentModelResourcePermission = modelResourcePermission;
	}
	private static ModelResourcePermission<Assignment> assignmentModelResourcePermission;
}
