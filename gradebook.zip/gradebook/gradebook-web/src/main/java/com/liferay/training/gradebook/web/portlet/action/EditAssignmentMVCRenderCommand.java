package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.exception.NoSuchAssignmentException;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class EditAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Setting Up An Assumption, This Is Going To Be Used For Adding A New Assignment
		Assignment assignment = null;
		
		// Lets Retrieve Assignment Id, Now If We Have Assignment Id (Purpose Is For Editing)
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId", 0);
		
		// If Editing Is The Purpose, We Need To Retrieve The Assigment Instances
		if(assignmentId > 0) {
			try {
				// Call For Assignment Service To Retrieve The Assignment Information and Pass To The Assignment Instance
				assignment = assignmentService.getAssignment(assignmentId);
			}
			catch (NoSuchAssignmentException nsae) {
				nsae.printStackTrace();
			}
			catch (PortalException pxe) {
				pxe.printStackTrace();
			}
		}
		
		// Want To Also Setup A Back Button To Return From Appropriate Individual Assignment Editing
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
		
		String redirect = renderRequest.getParameter("redirect");
		
		portletDisplay.setShowBackIcon(true);
		portletDisplay.setURLBack(redirect);
		
		// Setting The Assignment Information and Class Details To The Request
		renderRequest.setAttribute("assignment", assignment);
		renderRequest.setAttribute("assignmentClass", Assignment.class);
		
		// Return To Appropriate View JSP
		return "/assignment/edit_assignment.jsp";
	}
	
	@Reference
	private AssignmentService assignmentService;
}
